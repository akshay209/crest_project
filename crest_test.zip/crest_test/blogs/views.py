from rest_framework import viewsets, permissions
from .models import Blogs
from .serializers import BlogSerializer
from django.contrib.auth.models import User
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
import openpyxl
from django.http import HttpResponse
from django.utils.timezone import make_naive


@api_view(['POST'])
@permission_classes([AllowAny])  # This allows unauthenticated users to access
def register_user(request):
    username = request.data.get('username')
    password = request.data.get('password')

    if not username or not password:
        return Response({"error": "Username and password are required"}, status=status.HTTP_400_BAD_REQUEST)

    if User.objects.filter(username=username).exists():
        return Response({"error": "Username already exists"}, status=status.HTTP_400_BAD_REQUEST)

    user = User.objects.create_user(username=username, password=password)
    return Response({"message": "User created successfully"}, status=status.HTTP_201_CREATED)


@api_view(['POST'])
@permission_classes([AllowAny])  # Allow access to unauthenticated users
def login_user(request):
    username = request.data.get('username')
    password = request.data.get('password')

    if not username or not password:
        return Response({"error": "Username and password are required"}, status=status.HTTP_400_BAD_REQUEST)

    user = authenticate(username=username, password=password)

    if user is not None:
        # Generate JWT token
        refresh = RefreshToken.for_user(user)
        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token)
        }, status=status.HTTP_200_OK)

    return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)


# Product CRUD view
class BlogViewSet(viewsets.ModelViewSet):
    queryset = Blogs.objects.all()
    serializer_class = BlogSerializer

    def get_permissions(self):
        if self.request.method in ['GET']:
            return [permissions.AllowAny()]
        if self.request.user.is_staff:
            return [permissions.IsAuthenticated()]
        return [permissions.IsAdminUser()]


@api_view(['GET'])
@permission_classes([IsAuthenticated])  # Ensure only authenticated users can download
def export_blog_data(request):
    if not request.user.is_staff:
        return HttpResponse("Unauthorized", status=403)

    # Create a new Excel workbook and worksheet
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Blog Data"

    # Write header row
    headers = ["Title", "Description", "Price", "Discount", "SSN", "Created At", "Updated At"]
    sheet.append(headers)

    # Fetch blog data from the database
    blogs = Blogs.objects.all().values_list('title', 'description', 'price', 'discount', 'ssn', 'created_at', 'updated_at')

    for blog in blogs:
        # Convert timezone-aware datetime to naive (removing timezone info)
        title, description, price, discount, ssn, created_at, updated_at = blog

        created_at_naive = make_naive(created_at) if created_at else None
        updated_at_naive = make_naive(updated_at) if updated_at else None

        sheet.append([title, description, price, discount, ssn, created_at_naive, updated_at_naive])

    # Prepare response
    response = HttpResponse(content_type='application/vnd.openpyxl')
    response['Content-Disposition'] = 'attachment; filename="blog_data.xlsx"'

    # Save the workbook to the response
    workbook.save(response)
    return response