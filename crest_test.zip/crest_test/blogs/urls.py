from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import BlogViewSet, register_user, login_user, export_blog_data

router = DefaultRouter()
router.register(r'blogs', BlogViewSet)

urlpatterns = [
    path('register/', register_user),
    path('login/', login_user),
    path('', include(router.urls)),
    path('export-blog/', export_blog_data, name='export-blog'),
]
