from rest_framework import viewsets, filters
from .models import Product
from .serializers import ProductSerializer
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from .permissions import IsAdminUserOrReadOnly
import pandas as pd
from django.http import HttpResponse


class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAdminUserOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter, filters.SearchFilter]
    filterset_fields = ['title', 'description', 'price']
    ordering_fields = ['created_on', 'updated_on']
    search_fields = ['title', 'description']

    def perform_destroy(self, instance):
        instance.is_active = False
        instance.save()




def export_products(request):
    products = Product.objects.all().values()
    df = pd.DataFrame(products)

    # Convert timezone-aware datetime fields to naive
    df['created_on'] = df['created_on'].dt.tz_localize(None)
    df['updated_on'] = df['updated_on'].dt.tz_localize(None)

    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="products.xlsx"'
    df.to_excel(response, index=False)
    return response
